package com.example.WhatsAppClone;

import android.os.Bundle;

import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.AppCompatActivity;

public class FindUserActivity extends AppCompatActivity {

    private AlertController.RecycleListView mUserList;
    private AlertController.RecycleListView mUserListAdapter;
    private AlertController.RecycleListView mGetUserListLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_user);

        initializeRecyclerView();
    }

    private void initializeRecyclerView() {
        mUserList = findViewById(R.id.userList);
        mUserList.setNestedScrollingEnabled(false);

    }
}
